El c�digo en este fichero zip es solamente la parte del back-end en el servidor (particularmente el API REST). Para ver la parte de la app m�vil, incluyendo un fichero .apk con la versi�n final, todo est� en un repositorio GitHub referenciado en la memoria:

https://github.com/taotrooper/collectathon
