-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-09-2020 a las 23:08:37
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tfm`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bookedition`
--

CREATE TABLE `bookedition` (
  `BookID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `EditionID` int(11) NOT NULL,
  `ISBN` text COLLATE utf8_spanish2_ci DEFAULT NULL,
  `NroPaginas` int(11) DEFAULT NULL,
  `Editorial` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Edicion` int(11) DEFAULT NULL,
  `Idioma` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `Tipo` varchar(11) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `collection`
--

CREATE TABLE `collection` (
  `CollectionID` int(11) NOT NULL,
  `CollectionName` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `UserID` int(11) NOT NULL,
  `Publica` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comicedition`
--

CREATE TABLE `comicedition` (
  `ComicID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `EditionID` int(11) NOT NULL,
  `ISBNComic` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `TipoComic` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `FormatoComic` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NroComic` int(4) DEFAULT NULL,
  `EditorialComic` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Origen` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `IdiomaComic` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `edition`
--

CREATE TABLE `edition` (
  `EditionID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `ItemType` tinyint(1) NOT NULL,
  `CreatorUserID` int(11) NOT NULL,
  `Year` int(4) DEFAULT NULL,
  `EAN13` varchar(13) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `edition_collection`
--

CREATE TABLE `edition_collection` (
  `CollectionID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `ItemType` tinyint(1) NOT NULL,
  `EditionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `edition_user`
--

CREATE TABLE `edition_user` (
  `UserID` int(11) NOT NULL,
  `EditionID` int(11) NOT NULL,
  `IsOwned` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gameedition`
--

CREATE TABLE `gameedition` (
  `GameID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `EditionID` int(11) NOT NULL,
  `Plataforma` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `FormatoJuego` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `RegionJuego` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Distribuidora` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Estudio` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NotasEdJuego` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genre`
--

CREATE TABLE `genre` (
  `GenreID` int(11) NOT NULL,
  `GenreName` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `GenreType` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `item`
--

CREATE TABLE `item` (
  `ItemID` int(11) NOT NULL,
  `ItemName` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `ItemType` tinyint(1) NOT NULL,
  `SeriesID` int(11) DEFAULT NULL,
  `GenreID1` int(11) DEFAULT NULL,
  `GenreID2` int(11) DEFAULT NULL,
  `GenreID3` int(11) DEFAULT NULL,
  `CreatorUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `musicedition`
--

CREATE TABLE `musicedition` (
  `MusicID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `EditionID` int(11) NOT NULL,
  `Formato` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `NroPistas` int(2) DEFAULT NULL,
  `NroDiscos` int(2) DEFAULT 1,
  `Sello` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NotasVersion` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person`
--

CREATE TABLE `person` (
  `PersonID` int(11) NOT NULL,
  `Names` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `LastNames` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `CreatorUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person_item`
--

CREATE TABLE `person_item` (
  `PersonID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `Role` varchar(50) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `series`
--

CREATE TABLE `series` (
  `SeriesID` int(11) NOT NULL,
  `SeriesName` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Finished` tinyint(1) NOT NULL,
  `CreatorUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `FirebaseID` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `Email` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `Nickname` varchar(25) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `videoedition`
--

CREATE TABLE `videoedition` (
  `VideoID` int(11) NOT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `EditionID` int(11) DEFAULT NULL,
  `FormatoVideo` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `TipoVideo` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Sistema` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NroDiscosVideo` int(2) NOT NULL DEFAULT 1,
  `RegionVideo` varchar(11) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Temporada` int(2) DEFAULT NULL,
  `VolumenVideo` int(2) DEFAULT NULL,
  `NroEpisodios` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `website`
--

CREATE TABLE `website` (
  `WebsiteID` int(11) NOT NULL,
  `URL` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `Text` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `EntityType` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `EntityID` int(11) NOT NULL,
  `CreatorUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bookedition`
--
ALTER TABLE `bookedition`
  ADD PRIMARY KEY (`BookID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`CollectionID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indices de la tabla `comicedition`
--
ALTER TABLE `comicedition`
  ADD PRIMARY KEY (`ComicID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `edition`
--
ALTER TABLE `edition`
  ADD PRIMARY KEY (`EditionID`),
  ADD KEY `ItemID` (`ItemID`),
  ADD KEY `edition_ibfk_1` (`CreatorUserID`);

--
-- Indices de la tabla `edition_collection`
--
ALTER TABLE `edition_collection`
  ADD PRIMARY KEY (`CollectionID`,`ItemID`,`EditionID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `edition_user`
--
ALTER TABLE `edition_user`
  ADD PRIMARY KEY (`UserID`,`EditionID`) USING BTREE,
  ADD KEY `EditionID` (`EditionID`);

--
-- Indices de la tabla `gameedition`
--
ALTER TABLE `gameedition`
  ADD PRIMARY KEY (`GameID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`GenreID`);

--
-- Indices de la tabla `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`ItemID`),
  ADD KEY `item_ibfk_1` (`CreatorUserID`),
  ADD KEY `item_ibfk_2` (`GenreID1`),
  ADD KEY `item_ibfk_3` (`GenreID2`),
  ADD KEY `item_ibfk_4` (`GenreID3`),
  ADD KEY `item_ibfk_5` (`SeriesID`);

--
-- Indices de la tabla `musicedition`
--
ALTER TABLE `musicedition`
  ADD PRIMARY KEY (`MusicID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`PersonID`),
  ADD KEY `CreatorUserID` (`CreatorUserID`);

--
-- Indices de la tabla `person_item`
--
ALTER TABLE `person_item`
  ADD PRIMARY KEY (`PersonID`,`ItemID`,`Role`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`SeriesID`),
  ADD KEY `CreatorUserID` (`CreatorUserID`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indices de la tabla `videoedition`
--
ALTER TABLE `videoedition`
  ADD PRIMARY KEY (`VideoID`),
  ADD KEY `EditionID` (`EditionID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indices de la tabla `website`
--
ALTER TABLE `website`
  ADD PRIMARY KEY (`WebsiteID`),
  ADD KEY `CreatorUserID` (`CreatorUserID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bookedition`
--
ALTER TABLE `bookedition`
  MODIFY `BookID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `collection`
--
ALTER TABLE `collection`
  MODIFY `CollectionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comicedition`
--
ALTER TABLE `comicedition`
  MODIFY `ComicID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `edition`
--
ALTER TABLE `edition`
  MODIFY `EditionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `gameedition`
--
ALTER TABLE `gameedition`
  MODIFY `GameID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `genre`
--
ALTER TABLE `genre`
  MODIFY `GenreID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `item`
--
ALTER TABLE `item`
  MODIFY `ItemID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `musicedition`
--
ALTER TABLE `musicedition`
  MODIFY `MusicID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `person`
--
ALTER TABLE `person`
  MODIFY `PersonID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `series`
--
ALTER TABLE `series`
  MODIFY `SeriesID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `videoedition`
--
ALTER TABLE `videoedition`
  MODIFY `VideoID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `website`
--
ALTER TABLE `website`
  MODIFY `WebsiteID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bookedition`
--
ALTER TABLE `bookedition`
  ADD CONSTRAINT `bookedition_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bookedition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `collection`
--
ALTER TABLE `collection`
  ADD CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `comicedition`
--
ALTER TABLE `comicedition`
  ADD CONSTRAINT `comicedition_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comicedition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `edition`
--
ALTER TABLE `edition`
  ADD CONSTRAINT `edition_ibfk_1` FOREIGN KEY (`CreatorUserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `edition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `edition_collection`
--
ALTER TABLE `edition_collection`
  ADD CONSTRAINT `edition_collection_ibfk_1` FOREIGN KEY (`CollectionID`) REFERENCES `collection` (`CollectionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `edition_collection_ibfk_2` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `edition_collection_ibfk_3` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `edition_user`
--
ALTER TABLE `edition_user`
  ADD CONSTRAINT `edition_user_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `edition_user_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `gameedition`
--
ALTER TABLE `gameedition`
  ADD CONSTRAINT `gameedition_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gameedition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`CreatorUserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `item_ibfk_2` FOREIGN KEY (`GenreID1`) REFERENCES `genre` (`GenreID`) ON DELETE NO ACTION ON UPDATE SET NULL,
  ADD CONSTRAINT `item_ibfk_3` FOREIGN KEY (`GenreID2`) REFERENCES `genre` (`GenreID`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `item_ibfk_4` FOREIGN KEY (`GenreID3`) REFERENCES `genre` (`GenreID`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `item_ibfk_5` FOREIGN KEY (`SeriesID`) REFERENCES `series` (`SeriesID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `musicedition`
--
ALTER TABLE `musicedition`
  ADD CONSTRAINT `musicedition_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `musicedition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_ibfk_1` FOREIGN KEY (`CreatorUserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `person_item`
--
ALTER TABLE `person_item`
  ADD CONSTRAINT `person_item_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `person_item_ibfk_2` FOREIGN KEY (`PersonID`) REFERENCES `person` (`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `series`
--
ALTER TABLE `series`
  ADD CONSTRAINT `series_ibfk_1` FOREIGN KEY (`CreatorUserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `videoedition`
--
ALTER TABLE `videoedition`
  ADD CONSTRAINT `videoedition_ibfk_1` FOREIGN KEY (`EditionID`) REFERENCES `edition` (`EditionID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `videoedition_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `item` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `website`
--
ALTER TABLE `website`
  ADD CONSTRAINT `website_ibfk_1` FOREIGN KEY (`CreatorUserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
