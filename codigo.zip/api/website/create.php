<?php
	header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/website.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Website($db);

    $data = json_decode(file_get_contents("php://input"));

    $item->URL = $data->URL;
    $item->Text = $data->Text;
	$item->EntityType = $data->EntityType;
	$item->EntityID = $data->EntityID;
	$item->CreatorUserID = $data->CreatorUserID;
	
	$result = $item->createWebsite();
    
    if($result){
        $emp_arr = array(
            "WebsiteID" =>  $result
        );
        http_response_code(201);
        echo json_encode($emp_arr);
    } else{
		$err_arr = array(
			"WebsiteID" => null,
            "Error" => "Item could not be created"
        );
		/*http_response_code(404);*/
        echo json_encode($err_arr);
    }
?>