<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/website.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Website($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
    $item->WebsiteID = $data->WebsiteID;
    $item->URL = $data->URL;
	$item->Text = $data->Text;
    
    if($item->updateWebsite()){
        http_response_code(200);
		$emp_arr = array(
            "Message" =>  "Website data updated."
		);
		echo json_encode($emp_arr);
    } else {
		$emp_arr = array(
            "Message" =>  "Website could not be updated."
		);
		echo json_encode($emp_arr);
    }
	
?>