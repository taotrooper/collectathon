<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/website.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Website($db);

    $item->WebsiteID = isset($_GET['WebsiteID']) ? $_GET['WebsiteID'] : die();
  
    $item->getSingleWebsite();

    if($item->WebsiteID != null){
        // create array
        $emp_arr = array(
            "WebsiteID" =>  $item->WebsiteID,
            "URL" => $item->URL,
            "Text" => $item->Text,
			"EntityType" => $item->EntityType,
			"EntityID" => $item->EntityID,
			"CreatorUserID" => $item->CreatorUserID
        );
      
        http_response_code(200);
        echo json_encode($emp_arr);
    }
      
    else{
        http_response_code(404);
        echo json_encode("Website not found.");
    }
?>