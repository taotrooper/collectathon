<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/comic.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Comic($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
	$item->EditionID = $data->EditionID;
	$item->Year = $data->Year;
	$item->EAN13 = $data->EAN13;
	$item->ISBNComic = $data->ISBNComic;
	$item->TipoComic = $data->TipoComic;
	$item->FormatoComic = $data->FormatoComic;
	$item->NroComic = $data->NroComic;
	$item->EditorialComic = $data->EditorialComic;
	$item->Origen = $data->Origen;
	$item->IdiomaComic = $data->IdiomaComic;
    
    if($item->updateEdition()){
		http_response_code(200);
		$emp_arr = array(
            "Message" =>  "Cómic actualizado."
        );
		echo json_encode($emp_arr);
    } else{
		$emp_arr = array(
            "Message" =>  "No pudo actualizarse el cómic."
        );
		echo json_encode($emp_arr);
    }
?>