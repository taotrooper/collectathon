<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/comic.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Comic($db);
	$itemclass = new Item($db);
	
	/*$user = isset($_GET['user']) ? $_GET['user'] : die();*/
	
	$stmt = $items->getEditions();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "ItemID" =>  $ItemID,
				"ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"Year" => $Year,
				"EAN13" => $EAN13,
				"SeriesID" => $SeriesID,
				"SeriesName" => $SeriesName,
				"People" => $itemclass->getPeople($ItemID),
				"EditionID" => $EditionID,
				"CreatorID" => $CreatorUserID,
				"ComicID" => $ComicID,
				"ISBNComic" => $ISBNComic,
				"TipoComic" => $TipoComic,
				"FormatoComic" => $FormatoComic,
				"NroComic" => $NroComic,
				"EditorialComic" => $EditorialComic,
				"Origen" => $Origen,
				"IdiomaComic" => $IdiomaComic
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        /*http_response_code(404);*/
        echo json_encode(
            array("message" => "No record found.", "ItemCount" => 0)
        );
    }
?>