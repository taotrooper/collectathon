<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/comic.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Comic($db);
	$itemclass = new Item($db);

    $item->EditionID = isset($_GET['EditionID']) ? $_GET['EditionID'] : die();
  
    $item->getSingleEdition();

    if($item->ComicID != null){
        // create array
        $emp_arr = array(
            "ItemID" =>  $item->ItemID,
            "ItemName" => $item->ItemName,
			"ItemType" => $item->ItemType,
			"Year" => $item->Year,
			"EAN13" => $item->EAN13,
			"SeriesID" => $item->SeriesID,
			"SeriesName" => $item->SeriesName,
			"GenreID1" => $item->GenreID1,
			"GenreName1" => $item->GenreName1,
			"GenreID2" => $item->GenreID2,
			"GenreName2" => $item->GenreName2,
			"GenreID3" => $item->GenreID3,
			"GenreName3" => $item->GenreName3,
			"People" => $itemclass->getPeople($item->ItemID),
            "EditionID" => $item->EditionID,
			"CreatorUserID" => $item->CreatorUserID,
			"ComicID" => $item->ComicID,
			"ISBNComic" => $item->ISBNComic,
			"TipoComic" => $item->TipoComic,
			"FormatoComic" => $item->FormatoComic,
			"NroComic" => $item->NroComic,
			"EditorialComic" => $item->EditorialComic,
			"Origen" => $item->Origen,
			"IdiomaComic" => $item->IdiomaComic
        );
      
        http_response_code(200);
        echo json_encode($emp_arr);
    }
      
    else{
        http_response_code(404);
        echo json_encode("Comic not found.");
    }
?>