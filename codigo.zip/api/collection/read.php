<?php
    header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/collection.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Collection($db);
	
	$stmt = $items->getCollections();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $collectionArr = array();
        $collectionArr["body"] = array();
        $collectionArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "CollectionID" => $CollectionID,
                "CollectionName" => $CollectionName,
                "UserID" => $UserID,
				"Publica" => $Publica
            );

            array_push($collectionArr["body"], $e);
        }
        echo json_encode($collectionArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>