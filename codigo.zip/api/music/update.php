<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/music.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Music($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
	$item->EditionID = $data->EditionID;
	$item->Year = $data->Year;
	$item->EAN13 = $data->EAN13;
	$item->Formato = $data->Formato;
	$item->NroPistas = $data->NroPistas;
	$item->NroDiscos = $data->NroDiscos;
	$item->Sello = $data->Sello;
	$item->NotasVersion = $data->NotasVersion;
    
    if($item->updateEdition()){
		http_response_code(200);
		$emp_arr = array(
            "Message" =>  "Álbum actualizado."
        );
		echo json_encode($emp_arr);
    } else{
		$emp_arr = array(
            "Message" =>  "No pudo actualizarse el álbum."
        );
		echo json_encode($emp_arr);
    }
?>