<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/music.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Music($db);
	$itemclass = new Item($db);
	
	$stmt = $items->getEditions();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
			$Summary = $itemclass->getPeopleList($ItemID);
			if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
 			if($Formato != NULL) $Summary = $Summary.', '.$Formato;
			if($Sello != NULL) $Summary = $Summary.', '.$Sello;
			if($NotasVersion != NULL) $Summary = $Summary.', '.$NotasVersion;
			$e = array(
                "ItemID" =>  $ItemID,
				"ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"EditionID" => $EditionID,
				"Summary" => $Summary,
				"IsOwned" => $IsOwned
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>