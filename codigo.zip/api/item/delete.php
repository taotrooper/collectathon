<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/item.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Item($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
    $item->ItemID = $data->ItemID;
	$item->ItemTypeName = $data->ItemTypeName;
    $stmt = $item->usedByOthers();
    $itemCount = $stmt->rowCount();
	
	if($itemCount > 0) {
		echo json_encode(
			array(
				"message" => "No se puede borrar el item, lo están usando otros usuarios.",
				"otros" => $itemCount
			)
		);
	} else {
		if($item->deleteItem()){
			echo json_encode(
				array(
					"message" => "Item deleted.",
					"otros" => $itemCount
				)
			);
		} else{
			echo json_encode(
				array(
					"message" => "Data could not be deleted.",
					"otros" => $itemCount
				)
			);
		}
	}
?>