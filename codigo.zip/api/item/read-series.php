<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Item($db);
	
	$stmt = $items->getItemsOfSeries();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $people = $items->getPeopleListNoRole($ItemID);
			$Summary = $ItemName;
			if($people) {
				$Summary = $Summary . " (" . $people . ")";
			}
            $e = array(
                "ItemID" => $ItemID,
                "ItemSummary" => $Summary,
				"ItemType" => $ItemType
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>