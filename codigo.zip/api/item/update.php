<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/item.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Item($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
    $item->ItemID = $data->ItemID;
    $item->ItemName = $data->ItemName;
	$item->SeriesID = $data->SeriesID;
	$item->GenreID1 = $data->GenreID1;
	$item->GenreID2 = $data->GenreID2;
	$item->GenreID3 = $data->GenreID3;
    
    if($item->updateItem()){
		http_response_code(200);
		$emp_arr = array(
            "Message" =>  "Item data updated."
        );
		echo json_encode($emp_arr);
    } else{
		$emp_arr = array(
            "Message" =>  "Item could not be updated"
        );
		echo json_encode($emp_arr);
    }
?>