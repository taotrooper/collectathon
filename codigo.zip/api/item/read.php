<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Item($db);
	
	/*$user = isset($_GET['user']) ? $_GET['user'] : die();*/
	
	$stmt = $items->getItems();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "ItemID" => $ItemID,
                "ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"SeriesID" => $SeriesID,
				"GenreID1" => $GenreID1,
				"GenreID2" => $GenreID2,
				"GenreID3" => $GenreID3,
				"People" => $items->getPeople($ItemID),
                "CreatorUserID" => $CreatorUserID
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>