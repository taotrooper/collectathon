<?php
    class Collection{

        // Connection
        private $conn;

        // Table
        private $db_table = "collection";
		private $db_edition_collection = "edition_collection";

        // Columns
        public $CollectionID;
		public $CollectionName;
		public $UserID;
		public $Publica;
		public $Nickname;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET USER'S COLLECTION
        public function getCollections(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['user'])){
				$user = $_GET['user'];
				$sqlQuery = $sqlQuery . ' WHERE UserID = "' .$user. '" AND UserID>0 ORDER BY CollectionName';
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		public function getRandomCollections() {
			$sqlQuery = 'SELECT c.*, u.Nickname FROM ' . $this->db_table . ' c INNER JOIN user u ON c.UserID=u.UserID';
			if(isset($_GET['user'])){
				$user = $_GET['user'];
				$sqlQuery = $sqlQuery . ' WHERE c.UserID <> "' .$user. '" AND c.UserID>0 AND c.Publica>0
				ORDER BY RAND() LIMIT 10';
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
		}

        // CREATE
        public function createCollection(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        CollectionName = :CollectionName, 
                        UserID = :UserID,
						Publica = :Publica";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            /* $this->CollectionID=htmlspecialchars(strip_tags($this->CollectionID)); */
            $this->CollectionName=htmlspecialchars(strip_tags($this->CollectionName));
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
			$this->Publica=htmlspecialchars(strip_tags($this->Publica));
        
            // bind data
            /* $stmt->bindParam(":CollectionID", $this->CollectionID); */
            $stmt->bindParam(":CollectionName", $this->CollectionName);
            $stmt->bindParam(":UserID", $this->UserID);
			$stmt->bindParam(":Publica", $this->Publica);
        
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ single
        public function getSingleCollection(){
            $sqlQuery = "SELECT
                        CollectionID, 
                        CollectionName, 
                        UserID,
						Publica
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       CollectionID = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->CollectionID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->CollectionID = $dataRow['CollectionID'];
            $this->CollectionName = $dataRow['CollectionName'];
            $this->UserID = $dataRow['UserID'];
			$this->Publica = $dataRow['Publica'];
        }        

        // UPDATE
        public function updateCollection(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        CollectionID = :CollectionID, 
                        CollectionName = :CollectionName, 
                        UserID = :UserID,
						Publica = :Publica
                    WHERE 
                        CollectionID = :CollectionID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->CollectionID=htmlspecialchars(strip_tags($this->CollectionID));
            $this->CollectionName=htmlspecialchars(strip_tags($this->CollectionName));
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
			$this->Publica=htmlspecialchars(strip_tags($this->Publica));
        
            // bind data
            $stmt->bindParam(":CollectionID", $this->CollectionID);
            $stmt->bindParam(":CollectionName", $this->CollectionName);
            $stmt->bindParam(":UserID", $this->UserID);
			$stmt->bindParam(":Publica", $this->Publica);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteCollection(){
            $sqlQuery = "DELETE FROM ".$this->db_edition_collection." WHERE CollectionID = ?;
			DELETE FROM " . $this->db_table . " WHERE CollectionID = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->CollectionID=htmlspecialchars(strip_tags($this->CollectionID));
        
            $stmt->bindParam(1, $this->CollectionID);
			$stmt->bindParam(2, $this->CollectionID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>