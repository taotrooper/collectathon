<?php

	include 'edition.php';
    class Comic extends Edition {

        // Columns
		public $ComicID;
		public $ISBNComic;
		public $TipoComic;
		public $FormatoComic;
		public $NroComic;
		public $EditorialComicComic;
		public $Origen;
		public $IdiomaComicComic;

        // Db connection
        public function __construct($db){
            parent::__construct($db);
			$this->db_child_table = "comicedition";
			$this->ItemType = "5";
        }
		
		//CREATE
		protected function createChildEdition(){
            $sqlQuery2 = "INSERT INTO ". $this->db_child_table ." SET
				ItemID	= :ItemID,
				EditionID = :EditionID,
				ISBNComic = :ISBNComic,
				TipoComic = :TipoComic,
				FormatoComic = :FormatoComic,
				NroComic = :NroComic,
				EditorialComic = :EditorialComic,
				Origen	= :Origen,
				IdiomaComic = :IdiomaComic";
        
            $stmt2 = $this->conn->prepare($sqlQuery2);
        
            // sanitize
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->ISBNComic=htmlspecialchars(strip_tags($this->ISBNComic));
			$this->TipoComic=htmlspecialchars(strip_tags($this->TipoComic));
			$this->FormatoComic=htmlspecialchars(strip_tags($this->FormatoComic));
			$this->NroComic=htmlspecialchars(strip_tags($this->NroComic));
			$this->EditorialComic=htmlspecialchars(strip_tags($this->EditorialComic));
			$this->Origen=htmlspecialchars(strip_tags($this->Origen));
			$this->IdiomaComic=htmlspecialchars(strip_tags($this->IdiomaComic));
        
            // bind data
            $stmt2->bindParam(":ItemID", $this->ItemID);
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":ISBNComic", $this->ISBNComic);
			$stmt2->bindParam(":TipoComic", $this->TipoComic);
			$stmt2->bindParam(":FormatoComic", $this->FormatoComic);
			$stmt2->bindParam(":NroComic", $this->NroComic);
			$stmt2->bindParam(":EditorialComic", $this->EditorialComic);
			$stmt2->bindParam(":Origen", $this->Origen);
			$stmt2->bindParam(":IdiomaComic", $this->IdiomaComic);
			
			$result = $stmt2->execute();
			
            if($result){
               return $this->EditionID;
            }
            return false;
        }

        // READ single
        public function getSingleEdition() {
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, i.GenreID1, i.GenreID2, i.GenreID3,
					g1.GenreName GenreName1, g2.GenreName GenreName2, g3.GenreName GenreName3, e.CreatorUserID, c.* 
					FROM ' . $this->db_table. ' e 
					INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
					INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
					LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
					LEFT JOIN ' .$this->db_genre_table. ' g1 ON i.GenreID1 = g1.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g2 ON i.GenreID2 = g2.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g3 ON i.GenreID3 = g3.GenreID
                    WHERE 
                       e.EditionID = ?
                    LIMIT 0,1';

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->EditionID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->ItemID = $dataRow['ItemID'];
            $this->ItemName = $dataRow['ItemName'];
			$this->ItemType = $dataRow['ItemType'];
			$this->SeriesID = $dataRow['SeriesID'];
			$this->SeriesName = $dataRow['SeriesName'];
			$this->GenreID1 = $dataRow['GenreID1'];
			$this->GenreID2 = $dataRow['GenreID2'];
			$this->GenreID3 = $dataRow['GenreID3'];
			$this->GenreName1 = $dataRow['GenreName1'];
			$this->GenreName2 = $dataRow['GenreName2'];
			$this->GenreName3 = $dataRow['GenreName3'];
			$this->EditionID = $dataRow['EditionID'];
            $this->CreatorUserID = $dataRow['CreatorUserID'];
			$this->ComicID = $dataRow['ComicID'];
			$this->ISBNComic = $dataRow['ISBNComic'];
			$this->TipoComic = $dataRow['TipoComic'];
			$this->FormatoComic = $dataRow['FormatoComic'];
			$this->NroComic = $dataRow['NroComic'];
			$this->EditorialComic = $dataRow['EditorialComic'];
			$this->Year = $dataRow['Year'];
			$this->EAN13 = $dataRow['EAN13'];
			$this->Origen = $dataRow['Origen'];
			$this->IdiomaComic = $dataRow['IdiomaComic'];
        }

        // UPDATE
        protected function updateChildEdition() {
            $sqlQuery = "UPDATE
						". $this->db_table ."
					SET
						Year = :Year,
						EAN13 = :EAN13
					WHERE
						EditionID = :EditionID;
					UPDATE
                        ". $this->db_child_table ."
                    SET
						ISBNComic = :ISBNComic,
						TipoComic = :TipoComic,
						FormatoComic = :FormatoComic,
						NroComic = :NroComic,
						EditorialComic = :EditorialComic,
						Origen	= :Origen,
						IdiomaComic = :IdiomaComic
                    WHERE 
                        EditionID = :EditionID";
        
            $stmt2 = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Year=htmlspecialchars(strip_tags($this->Year));
			$this->EAN13=htmlspecialchars(strip_tags($this->EAN13));
			$this->ISBNComic=htmlspecialchars(strip_tags($this->ISBNComic));
			$this->TipoComic=htmlspecialchars(strip_tags($this->TipoComic));
			$this->FormatoComic=htmlspecialchars(strip_tags($this->FormatoComic));
			$this->NroComic=htmlspecialchars(strip_tags($this->NroComic));
			$this->EditorialComic=htmlspecialchars(strip_tags($this->EditorialComic));
			$this->Origen=htmlspecialchars(strip_tags($this->Origen));
			$this->IdiomaComic=htmlspecialchars(strip_tags($this->IdiomaComic));
        
            // bind data
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Year", $this->Year);
			$stmt2->bindParam(":EAN13", $this->EAN13);
			$stmt2->bindParam(":ISBNComic", $this->ISBNComic);
			$stmt2->bindParam(":TipoComic", $this->TipoComic);
			$stmt2->bindParam(":FormatoComic", $this->FormatoComic);
			$stmt2->bindParam(":NroComic", $this->NroComic);
			$stmt2->bindParam(":EditorialComic", $this->EditorialComic);
			$stmt2->bindParam(":Origen", $this->Origen);
			$stmt2->bindParam(":IdiomaComic", $this->IdiomaComic);
        
            if($stmt2->execute()){
               return true;
            }
            return false;
        }

    }
?>