<?php

	include 'edition.php';
    class Game extends Edition {

        // Columns
		public $GameID;
		public $Plataforma;
		public $FormatoJuego;
		public $RegionJuego;
		public $Distribuidora;
		public $Estudio;
		public $NotasEdJuego;

        // Db connection
        public function __construct($db){
            parent::__construct($db);
			$this->db_child_table = "gameedition";
			$this->ItemType = "4";
        }
		
		//CREATE
		protected function createChildEdition(){
            $sqlQuery2 = "INSERT INTO ". $this->db_child_table ." SET
				ItemID	= :ItemID,
				EditionID = :EditionID,
				Plataforma = :Plataforma,
				FormatoJuego = :FormatoJuego,
				RegionJuego	= :RegionJuego,
				Distribuidora = :Distribuidora,
				Estudio = :Estudio,
				NotasEdJuego = :NotasEdJuego";
        
            $stmt2 = $this->conn->prepare($sqlQuery2);
        
            // sanitize
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Plataforma=htmlspecialchars(strip_tags($this->Plataforma));
			$this->FormatoJuego=htmlspecialchars(strip_tags($this->FormatoJuego));
			$this->RegionJuego=htmlspecialchars(strip_tags($this->RegionJuego));
			$this->Distribuidora=htmlspecialchars(strip_tags($this->Distribuidora));
			$this->Estudio=htmlspecialchars(strip_tags($this->Estudio));
			$this->NotasEdJuego=htmlspecialchars(strip_tags($this->NotasEdJuego));
        
            // bind data
            $stmt2->bindParam(":ItemID", $this->ItemID);
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Plataforma", $this->Plataforma);
			$stmt2->bindParam(":FormatoJuego", $this->FormatoJuego);
			$stmt2->bindParam(":RegionJuego", $this->RegionJuego);
			$stmt2->bindParam(":Distribuidora", $this->Distribuidora);
			$stmt2->bindParam(":Estudio", $this->Estudio);
			$stmt2->bindParam(":NotasEdJuego", $this->NotasEdJuego);
			
			$result = $stmt2->execute();
			
            if($result){
               return $this->EditionID;
            }
            return false;
        }

        // READ single
        public function getSingleEdition() {
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, i.GenreID1, i.GenreID2, i.GenreID3,
					g1.GenreName GenreName1, g2.GenreName GenreName2, g3.GenreName GenreName3, e.CreatorUserID, c.* 
					FROM ' . $this->db_table. ' e 
					INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
					INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
					LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
					LEFT JOIN ' .$this->db_genre_table. ' g1 ON i.GenreID1 = g1.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g2 ON i.GenreID2 = g2.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g3 ON i.GenreID3 = g3.GenreID
                    WHERE 
                       e.EditionID = ?
                    LIMIT 0,1';

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->EditionID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->ItemID = $dataRow['ItemID'];
            $this->ItemName = $dataRow['ItemName'];
			$this->ItemType = $dataRow['ItemType'];
			$this->SeriesID = $dataRow['SeriesID'];
			$this->SeriesName = $dataRow['SeriesName'];
			$this->GenreID1 = $dataRow['GenreID1'];
			$this->GenreID2 = $dataRow['GenreID2'];
			$this->GenreID3 = $dataRow['GenreID3'];
			$this->GenreName1 = $dataRow['GenreName1'];
			$this->GenreName2 = $dataRow['GenreName2'];
			$this->GenreName3 = $dataRow['GenreName3'];
			$this->EditionID = $dataRow['EditionID'];
            $this->CreatorUserID = $dataRow['CreatorUserID'];
			$this->GameID = $dataRow['GameID'];
			$this->Plataforma = $dataRow['Plataforma'];
			$this->FormatoJuego = $dataRow['FormatoJuego'];
			$this->RegionJuego = $dataRow['RegionJuego'];
			$this->Year = $dataRow['Year'];
			$this->EAN13 = $dataRow['EAN13'];
			$this->Distribuidora = $dataRow['Distribuidora'];
			$this->Estudio = $dataRow['Estudio'];
			$this->NotasEdJuego = $dataRow['NotasEdJuego'];
        }

        // UPDATE
        protected function updateChildEdition() {
            $sqlQuery = "UPDATE
						". $this->db_table ."
					SET
						Year = :Year,
						EAN13 = :EAN13
					WHERE
						EditionID = :EditionID;
					UPDATE
                        ". $this->db_child_table ."
                    SET
						Plataforma = :Plataforma,
						FormatoJuego = :FormatoJuego,
						RegionJuego	= :RegionJuego,
						Distribuidora = :Distribuidora,
						Estudio = :Estudio,
						NotasEdJuego = :NotasEdJuego
                    WHERE 
                        EditionID = :EditionID";
        
            $stmt2 = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Year=htmlspecialchars(strip_tags($this->Year));
			$this->EAN13=htmlspecialchars(strip_tags($this->EAN13));
			$this->Plataforma=htmlspecialchars(strip_tags($this->Plataforma));
			$this->FormatoJuego=htmlspecialchars(strip_tags($this->FormatoJuego));
			$this->RegionJuego=htmlspecialchars(strip_tags($this->RegionJuego));
			$this->Distribuidora=htmlspecialchars(strip_tags($this->Distribuidora));
			$this->Estudio=htmlspecialchars(strip_tags($this->Estudio));
			$this->NotasEdJuego=htmlspecialchars(strip_tags($this->NotasEdJuego));
        
            // bind data
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Year", $this->Year);
			$stmt2->bindParam(":EAN13", $this->EAN13);
			$stmt2->bindParam(":Plataforma", $this->Plataforma);
			$stmt2->bindParam(":FormatoJuego", $this->FormatoJuego);
			$stmt2->bindParam(":RegionJuego", $this->RegionJuego);
			$stmt2->bindParam(":Distribuidora", $this->Distribuidora);
			$stmt2->bindParam(":Estudio", $this->Estudio);
			$stmt2->bindParam(":NotasEdJuego", $this->NotasEdJuego);
        
            if($stmt2->execute()){
               return true;
            }
            return false;
        }

    }
?>