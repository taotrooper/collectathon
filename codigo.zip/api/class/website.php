<?php
    class Website{

        // Connection
        private $conn;

        // Table
        private $db_table = "website";

        // Columns
        public $WebsiteID;
		public $URL;
		public $Text;
		public $EntityType;
		public $EntityID;
		public $CreatorUserID;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET ITEMS
        public function getWebsites(){
			if(isset($_GET['type']) && isset($_GET['id'])){
				$sqlQuery = "SELECT * FROM " . $this->db_table. 
				" WHERE EntityType = '" .$_GET['type']. "' AND EntityID = " .$_GET['id'];
				$stmt = $this->conn->prepare($sqlQuery);
				$stmt->execute();
				return $stmt;
			}
			return null;
        }

        // CREATE
        public function createWebsite(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        URL = :URL, 
						Text = :Text, 
                        EntityType = :EntityType,
						EntityID = :EntityID,
						CreatorUserID = :CreatorUserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->URL=htmlspecialchars(strip_tags($this->URL));
			$this->Text=htmlspecialchars(strip_tags($this->Text));
			$this->EntityType=htmlspecialchars(strip_tags($this->EntityType));
            $this->EntityID=htmlspecialchars(strip_tags($this->EntityID));
			$this->CreatorUserID=htmlspecialchars(strip_tags($this->CreatorUserID));
        
            // bind data
            $stmt->bindParam(":URL", $this->URL);
			$stmt->bindParam(":Text", $this->Text);
            $stmt->bindParam(":EntityType", $this->EntityType);
			$stmt->bindParam(":EntityID", $this->EntityID);
			$stmt->bindParam(":CreatorUserID", $this->CreatorUserID);
			
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ single
        public function getSingleWebsite(){
            $sqlQuery = "SELECT *
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       WebsiteID = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->WebsiteID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->WebsiteID = $dataRow['WebsiteID'];
            $this->Text = $dataRow['Text'];
			$this->URL = $dataRow['URL'];
			$this->EntityType = $dataRow['EntityType'];
            $this->EntityID = $dataRow['EntityID'];
			$this->CreatorUserID = $dataRow['CreatorUserID'];
        }        

        // UPDATE
        public function updateWebsite(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        URL = :URL, 
						Text = :Text
                    WHERE 
                        WebsiteID = :WebsiteID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->WebsiteID=htmlspecialchars(strip_tags($this->WebsiteID));
            $this->URL=htmlspecialchars(strip_tags($this->URL));
			$this->Text=htmlspecialchars(strip_tags($this->Text));
        
            // bind data
            $stmt->bindParam(":WebsiteID", $this->WebsiteID);
            $stmt->bindParam(":URL", $this->URL);
			$stmt->bindParam(":Text", $this->Text);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }	

        // DELETE
        function deleteWebsite(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE WebsiteID = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->WebsiteID=htmlspecialchars(strip_tags($this->WebsiteID));
        
            $stmt->bindParam(1, $this->WebsiteID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>