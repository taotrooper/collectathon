<?php
    class User{

        // Connection
        private $conn;

        // Table
        private $db_table = "user";

        // Columns
        public $UserID;
		public $FirebaseID;
		public $Email;
		public $Nickname;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// CREATE
        public function createUser(){
			if(!$this->Email) return false;
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        FirebaseID = :FirebaseID, 
                        Email = :Email";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->FirebaseID=htmlspecialchars(strip_tags($this->FirebaseID));
            $this->Email=htmlspecialchars(strip_tags($this->Email));
        
            // bind data
            $stmt->bindParam(":FirebaseID", $this->FirebaseID);
            $stmt->bindParam(":Email", $this->Email);
        
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ
        public function getUser(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['UserID'])){
				$sqlQuery = $sqlQuery . ' WHERE UserID = '.$_GET['UserID'].' LIMIT 0,1';
			} else if (isset($_GET['Email'])){
				$sqlQuery = $sqlQuery . ' WHERE Email = '.$_GET['Email'].' LIMIT 0,1';
			}

            $stmt = $this->conn->prepare($sqlQuery);

            //$stmt->bindParam(1, $this->UserID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->UserID = $dataRow['UserID'];
            $this->FirebaseID = $dataRow['FirebaseID'];
            $this->Email = $dataRow['Email'];
			$this->Nickname = $dataRow['Nickname'];
        }
		
		public function getUserID() {
			$sqlQuery = 'SELECT * FROM ' . $this->db_table . ' WHERE Email = ? LIMIT 0,1';
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->bindParam(1, $this->Email);
            $stmt->execute();
            if($stmt->rowCount() == 0) return 0;
			$dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            return $dataRow['UserID'];
		}

        // UPDATE
        public function updateUser(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        FirebaseID = :FirebaseID, 
                        Email = :Email,
						Nickname = :Nickname
                    WHERE 
                        UserID = :UserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
            $this->FirebaseID=htmlspecialchars(strip_tags($this->FirebaseID));
            $this->Email=htmlspecialchars(strip_tags($this->Email));
			$this->Nickname=htmlspecialchars(strip_tags($this->Nickname));
        
            // bind data
            $stmt->bindParam(":UserID", $this->UserID);
            $stmt->bindParam(":FirebaseID", $this->FirebaseID);
            $stmt->bindParam(":Email", $this->Email);
			$stmt->bindParam(":Nickname", $this->Nickname);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteUser(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE UserID = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
        
            $stmt->bindParam(1, $this->UserID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>