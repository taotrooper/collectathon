<?php

	include 'edition.php';
    class Video extends Edition {

        // Columns
		public $VideoID;
		public $FormatoVideo;
		public $TipoVideo;
		public $Sistema;
		public $NroDiscosVideo;
		public $RegionVideo;
		public $Temporada;
		public $VolumenVideo;
		public $NroEpisodios;

        // Db connection
        public function __construct($db){
            parent::__construct($db);
			$this->db_child_table = "videoedition";
			$this->ItemType = "3";
        }
		
		//CREATE
		protected function createChildEdition(){
            $sqlQuery2 = "INSERT INTO ". $this->db_child_table ." SET
				ItemID	= :ItemID,
				EditionID = :EditionID,
				FormatoVideo = :FormatoVideo,
				TipoVideo = :TipoVideo,
				Sistema = :Sistema,
				NroDiscosVideo = :NroDiscosVideo,
				RegionVideo	= :RegionVideo,
				Temporada = :Temporada,
				VolumenVideo = :VolumenVideo,
				NroEpisodios = :NroEpisodios";
        
            $stmt2 = $this->conn->prepare($sqlQuery2);
        
            // sanitize
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->FormatoVideo=htmlspecialchars(strip_tags($this->FormatoVideo));
			$this->TipoVideo=htmlspecialchars(strip_tags($this->TipoVideo));
			$this->Sistema=htmlspecialchars(strip_tags($this->Sistema));
			$this->NroDiscosVideo=htmlspecialchars(strip_tags($this->NroDiscosVideo));
			$this->RegionVideo=htmlspecialchars(strip_tags($this->RegionVideo));
			$this->Temporada=htmlspecialchars(strip_tags($this->Temporada));
			$this->VolumenVideo=htmlspecialchars(strip_tags($this->VolumenVideo));
			$this->NroEpisodios=htmlspecialchars(strip_tags($this->NroEpisodios));
        
            // bind data
            $stmt2->bindParam(":ItemID", $this->ItemID);
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":FormatoVideo", $this->FormatoVideo);
			$stmt2->bindParam(":TipoVideo", $this->TipoVideo);
			$stmt2->bindParam(":Sistema", $this->Sistema);
			$stmt2->bindParam(":NroDiscosVideo", $this->NroDiscosVideo);
			$stmt2->bindParam(":RegionVideo", $this->RegionVideo);
			$stmt2->bindParam(":Temporada", $this->Temporada);
			$stmt2->bindParam(":VolumenVideo", $this->VolumenVideo);
			$stmt2->bindParam(":NroEpisodios", $this->NroEpisodios);
			
			$result = $stmt2->execute();
			
            if($result){
               return $this->EditionID;
            }
            return false;
        }

        // READ single
        public function getSingleEdition() {
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, i.GenreID1, i.GenreID2, i.GenreID3,
					g1.GenreName GenreName1, g2.GenreName GenreName2, g3.GenreName GenreName3, e.CreatorUserID, c.* 
					FROM ' . $this->db_table. ' e 
					INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
					INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
					LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
					LEFT JOIN ' .$this->db_genre_table. ' g1 ON i.GenreID1 = g1.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g2 ON i.GenreID2 = g2.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g3 ON i.GenreID3 = g3.GenreID
                    WHERE 
                       e.EditionID = ?
                    LIMIT 0,1';

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->EditionID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->ItemID = $dataRow['ItemID'];
            $this->ItemName = $dataRow['ItemName'];
			$this->ItemType = $dataRow['ItemType'];
			$this->SeriesID = $dataRow['SeriesID'];
			$this->SeriesName = $dataRow['SeriesName'];
			$this->GenreID1 = $dataRow['GenreID1'];
			$this->GenreID2 = $dataRow['GenreID2'];
			$this->GenreID3 = $dataRow['GenreID3'];
			$this->GenreName1 = $dataRow['GenreName1'];
			$this->GenreName2 = $dataRow['GenreName2'];
			$this->GenreName3 = $dataRow['GenreName3'];
			$this->EditionID = $dataRow['EditionID'];
            $this->CreatorUserID = $dataRow['CreatorUserID'];
			$this->VideoID = $dataRow['VideoID'];
			$this->FormatoVideo = $dataRow['FormatoVideo'];
			$this->TipoVideo = $dataRow['TipoVideo'];
			$this->Sistema = $dataRow['Sistema'];
			$this->NroDiscosVideo = $dataRow['NroDiscosVideo'];
			$this->Year = $dataRow['Year'];
			$this->EAN13 = $dataRow['EAN13'];
			$this->RegionVideo = $dataRow['RegionVideo'];
			$this->Temporada = $dataRow['Temporada'];
			$this->VolumenVideo = $dataRow['VolumenVideo'];
			$this->NroEpisodios = $dataRow['NroEpisodios'];
        }

        // UPDATE
        protected function updateChildEdition() {
            $sqlQuery = "UPDATE
						". $this->db_table ."
					SET
						Year = :Year,
						EAN13 = :EAN13
					WHERE
						EditionID = :EditionID;
					UPDATE
                        ". $this->db_child_table ."
                    SET
						FormatoVideo = :FormatoVideo,
						TipoVideo = :TipoVideo,
						Sistema = :Sistema,
						NroDiscosVideo = :NroDiscosVideo,
						RegionVideo	= :RegionVideo,
						Temporada = :Temporada,
						VolumenVideo = :VolumenVideo,
						NroEpisodios = :NroEpisodios
                    WHERE 
                        EditionID = :EditionID";
        
            $stmt2 = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Year=htmlspecialchars(strip_tags($this->Year));
			$this->EAN13=htmlspecialchars(strip_tags($this->EAN13));
			$this->FormatoVideo=htmlspecialchars(strip_tags($this->FormatoVideo));
			$this->TipoVideo=htmlspecialchars(strip_tags($this->TipoVideo));
			$this->Sistema=htmlspecialchars(strip_tags($this->Sistema));
			$this->NroDiscosVideo=htmlspecialchars(strip_tags($this->NroDiscosVideo));
			$this->RegionVideo=htmlspecialchars(strip_tags($this->RegionVideo));
			$this->Temporada=htmlspecialchars(strip_tags($this->Temporada));
			$this->VolumenVideo=htmlspecialchars(strip_tags($this->VolumenVideo));
			$this->NroEpisodios=htmlspecialchars(strip_tags($this->NroEpisodios));
        
            // bind data
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Year", $this->Year);
			$stmt2->bindParam(":EAN13", $this->EAN13);
			$stmt2->bindParam(":FormatoVideo", $this->FormatoVideo);
			$stmt2->bindParam(":TipoVideo", $this->TipoVideo);
			$stmt2->bindParam(":Sistema", $this->Sistema);
			$stmt2->bindParam(":NroDiscosVideo", $this->NroDiscosVideo);
			$stmt2->bindParam(":RegionVideo", $this->RegionVideo);
			$stmt2->bindParam(":Temporada", $this->Temporada);
			$stmt2->bindParam(":VolumenVideo", $this->VolumenVideo);
			$stmt2->bindParam(":NroEpisodios", $this->NroEpisodios);
        
            if($stmt2->execute()){
               return true;
            }
            return false;
        }

    }
?>