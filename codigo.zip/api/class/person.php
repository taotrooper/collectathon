<?php
    class Person{

        // Connection
        private $conn;

        // Table
        private $db_table = "person";
		private $db_item = "person_item";

        // Columns
        public $PersonID;
		public $Names;
		public $LastNames;
		public $ItemID;
		public $Role;
		public $CreatorUserID;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// CREATE
        public function createPerson(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        Names = :Names, 
                        LastNames = :LastNames,
						CreatorUserID = :CreatorUserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->Names=htmlspecialchars(strip_tags($this->Names));
            $this->LastNames=htmlspecialchars(strip_tags($this->LastNames));
			$this->CreatorUserID=htmlspecialchars(strip_tags($this->CreatorUserID));
        
            // bind data
            $stmt->bindParam(":Names", $this->Names);
            $stmt->bindParam(":LastNames", $this->LastNames);
			$stmt->bindParam(":CreatorUserID", $this->CreatorUserID);
        
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ SINGLE PERSON
        public function getSinglePerson(){
            $sqlQuery = "SELECT
                        PersonID, 
                        Names, 
                        LastNames,
						CreatorUserID
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       PersonID = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->PersonID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->PersonID = $dataRow['PersonID'];
            $this->Names = $dataRow['Names'];
            $this->LastNames = $dataRow['LastNames'];
			$this->CreatorUserID = $dataRow['CreatorUserID'];
        }

		// GET PEOPLE
        public function getPeople(){
            $sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['name'])){
				$term = $_GET['name'];
				$sqlQuery = $sqlQuery . ' WHERE Names LIKE "%' .$term. '%" OR LastNames LIKE "%' .$term. '%"';
			}
			$sqlQuery = $sqlQuery . ' ORDER BY CONCAT(LastNames, Names)';
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        public function getPeopleForItem(){
            $sqlQuery = 'SELECT p.PersonID, p.Names, p.LastNames, i.Role FROM ' . $this->db_item.
            ' i INNER JOIN ' .$this->db_table. ' p ON p.PersonID=i.PersonID';
			if(isset($_GET['ItemID'])){
				$term = $_GET['ItemID'];
				$sqlQuery = $sqlQuery . ' WHERE ItemID = ' .$term. '';
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // UPDATE
        public function updatePerson(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        Names = :Names, 
                        LastNames = :LastNames
                    WHERE 
                        PersonID = :PersonID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->PersonID=htmlspecialchars(strip_tags($this->PersonID));
            $this->Names=htmlspecialchars(strip_tags($this->Names));
            $this->LastNames=htmlspecialchars(strip_tags($this->LastNames));
        
            // bind data
            $stmt->bindParam(":PersonID", $this->PersonID);
            $stmt->bindParam(":Names", $this->Names);
            $stmt->bindParam(":LastNames", $this->LastNames);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deletePerson(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE PersonID = ?;
			DELETE FROM website WHERE EntityID = ? && EntityType = 'person';";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->PersonID=htmlspecialchars(strip_tags($this->PersonID));
        
            $stmt->bindParam(1, $this->PersonID);
			$stmt->bindParam(2, $this->PersonID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
		
		// ADD TO ITEM
		public function addPersonToItem(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_item ."
                    SET
                        PersonID = :PersonID, 
						ItemID = :ItemID, 
						Role = :Role";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->PersonID=htmlspecialchars(strip_tags($this->PersonID));
			$this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
			$this->Role=htmlspecialchars(strip_tags($this->Role));
        
            // bind data
            $stmt->bindParam(":PersonID", $this->PersonID);
			$stmt->bindParam(":ItemID", $this->ItemID);
			$stmt->bindParam(":Role", $this->Role);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }
		
		// REMOVE FROM ITEM
        function removePersonFromItem(){
            $sqlQuery = "DELETE FROM " . $this->db_item . 
				" WHERE PersonID = ? AND ItemID = ? AND Role = ?";
				
            $stmt = $this->conn->prepare($sqlQuery);
			
			$this->PersonID=htmlspecialchars(strip_tags($this->PersonID));
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
			$this->Role=htmlspecialchars(strip_tags($this->Role));
        
            $stmt->bindParam(1, $this->PersonID);
			$stmt->bindParam(2, $this->ItemID);
			$stmt->bindParam(3, $this->Role);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>