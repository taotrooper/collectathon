<?php
    class Genre{

        // Connection
        private $conn;

        // Table
        private $db_table = "genre";

        // Columns
        public $GenreID;
		public $GenreName;
		public $GenreType;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET
        public function getGenres(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['type'])){
				switch($_GET['type']) {
					case 'book':
					case 'video':
						$sqlQuery = $sqlQuery . ' WHERE GenreType LIKE "%narrativa%"';
					break;
					case 'music':
						$sqlQuery = $sqlQuery . ' WHERE GenreType LIKE "%musical%"';
					break;
					case 'game':
						$sqlQuery = $sqlQuery . ' WHERE GenreType LIKE "%gaming%"';
					break;
					case 'comic':
						$sqlQuery = $sqlQuery . ' WHERE GenreType LIKE "%narrativa%" OR GenreType LIKE "%manga%"';
					break;
				}
			} else if(isset($_GET['name'])){
				$name = $_GET['name'];
				$sqlQuery = $sqlQuery . ' WHERE GenreName LIKE "%' .$name. '%"';
			}
			$sqlQuery = $sqlQuery . ' ORDER BY GenreName, GenreType';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // READ single
        public function getSingleGenre(){
            $sqlQuery = "SELECT *
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       GenreID = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->GenreID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->GenreID = $dataRow['GenreID'];
            $this->GenreName = $dataRow['GenreName'];
			$this->GenreType = $dataRow['GenreType'];
        }        

    }
?>