<?php

	include 'edition.php';
    class Music extends Edition {

        // Columns
		public $MusicID;
		public $Formato;
		public $NroPistas;
		public $NroDiscos;
		public $Sello;
		public $NotasVersion;

        // Db connection
        public function __construct($db){
            parent::__construct($db);
			$this->db_child_table = "musicedition";
			$this->ItemType = "2";
        }
		
		//CREATE
		protected function createChildEdition(){
            $sqlQuery2 = "INSERT INTO ". $this->db_child_table ." SET
				ItemID	= :ItemID,
				EditionID = :EditionID,
				Formato = :Formato,
				NroPistas = :NroPistas,
				NroDiscos = :NroDiscos,
				Sello	= :Sello,
				NotasVersion = :NotasVersion";
        
            $stmt2 = $this->conn->prepare($sqlQuery2);
        
            // sanitize
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Formato=htmlspecialchars(strip_tags($this->Formato));
			$this->NroPistas=htmlspecialchars(strip_tags($this->NroPistas));
			$this->NroDiscos=htmlspecialchars(strip_tags($this->NroDiscos));
			$this->Sello=htmlspecialchars(strip_tags($this->Sello));
			$this->NotasVersion=htmlspecialchars(strip_tags($this->NotasVersion));
        
            // bind data
            $stmt2->bindParam(":ItemID", $this->ItemID);
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Formato", $this->Formato);
			$stmt2->bindParam(":NroPistas", $this->NroPistas);
			$stmt2->bindParam(":NroDiscos", $this->NroDiscos);
			$stmt2->bindParam(":Sello", $this->Sello);
			$stmt2->bindParam(":NotasVersion", $this->NotasVersion);
			
			$result = $stmt2->execute();
			
            if($result){
               return $this->EditionID;
            }
            return false;
        }

        // READ single
        public function getSingleEdition() {
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, i.GenreID1, i.GenreID2, i.GenreID3,
					g1.GenreName GenreName1, g2.GenreName GenreName2, g3.GenreName GenreName3, e.CreatorUserID, c.* 
					FROM ' . $this->db_table. ' e 
					INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
					INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
					LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
					LEFT JOIN ' .$this->db_genre_table. ' g1 ON i.GenreID1 = g1.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g2 ON i.GenreID2 = g2.GenreID
					LEFT JOIN ' .$this->db_genre_table. ' g3 ON i.GenreID3 = g3.GenreID
                    WHERE 
                       e.EditionID = ?
                    LIMIT 0,1';

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->EditionID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->ItemID = $dataRow['ItemID'];
            $this->ItemName = $dataRow['ItemName'];
			$this->ItemType = $dataRow['ItemType'];
			$this->SeriesID = $dataRow['SeriesID'];
			$this->SeriesName = $dataRow['SeriesName'];
			$this->GenreID1 = $dataRow['GenreID1'];
			$this->GenreID2 = $dataRow['GenreID2'];
			$this->GenreID3 = $dataRow['GenreID3'];
			$this->GenreName1 = $dataRow['GenreName1'];
			$this->GenreName2 = $dataRow['GenreName2'];
			$this->GenreName3 = $dataRow['GenreName3'];
			$this->EditionID = $dataRow['EditionID'];
            $this->CreatorUserID = $dataRow['CreatorUserID'];
			$this->MusicID = $dataRow['MusicID'];
			$this->Formato = $dataRow['Formato'];
			$this->NroPistas = $dataRow['NroPistas'];
			$this->NroDiscos = $dataRow['NroDiscos'];
			$this->Year = $dataRow['Year'];
			$this->EAN13 = $dataRow['EAN13'];
			$this->Sello = $dataRow['Sello'];
			$this->NotasVersion = $dataRow['NotasVersion'];
        }

        // UPDATE
        protected function updateChildEdition() {
            $sqlQuery = "UPDATE
						". $this->db_table ."
					SET
						Year = :Year,
						EAN13 = :EAN13
					WHERE
						EditionID = :EditionID;
					UPDATE
                        ". $this->db_child_table ."
                    SET
						Formato = :Formato,
						NroPistas = :NroPistas,
						NroDiscos = :NroDiscos,
						Sello	= :Sello,
						NotasVersion = :NotasVersion
                    WHERE 
                        EditionID = :EditionID";
        
            $stmt2 = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
			$this->Year=htmlspecialchars(strip_tags($this->Year));
			$this->EAN13=htmlspecialchars(strip_tags($this->EAN13));
			$this->Formato=htmlspecialchars(strip_tags($this->Formato));
			$this->NroPistas=htmlspecialchars(strip_tags($this->NroPistas));
			$this->NroDiscos=htmlspecialchars(strip_tags($this->NroDiscos));
			$this->Sello=htmlspecialchars(strip_tags($this->Sello));
			$this->NotasVersion=htmlspecialchars(strip_tags($this->NotasVersion));
        
            // bind data
			$stmt2->bindParam(":EditionID", $this->EditionID);
			$stmt2->bindParam(":Year", $this->Year);
			$stmt2->bindParam(":EAN13", $this->EAN13);
			$stmt2->bindParam(":Formato", $this->Formato);
			$stmt2->bindParam(":NroPistas", $this->NroPistas);
			$stmt2->bindParam(":NroDiscos", $this->NroDiscos);
			$stmt2->bindParam(":Sello", $this->Sello);
			$stmt2->bindParam(":NotasVersion", $this->NotasVersion);
        
            if($stmt2->execute()){
               return true;
            }
            return false;
        }

    }
?>