<?php
    class Series{

        // Connection
        private $conn;

        // Table
        private $db_table = "series";

        // Columns
        public $SeriesID;
		public $SeriesName;
		public $Finished;
		public $CreatorUserID;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET ITEMS
        public function getSeries(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['name'])){
				$name = $_GET['name'];
				$sqlQuery = $sqlQuery . ' WHERE SeriesName LIKE "%' .$name. '%"';
			}
			$sqlQuery = $sqlQuery . ' ORDER BY SeriesName';
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createSeries(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        SeriesName = :SeriesName, 
						Finished = :Finished, 
                        CreatorUserID = :CreatorUserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->SeriesName=htmlspecialchars(strip_tags($this->SeriesName));
			$this->Finished=htmlspecialchars(strip_tags($this->Finished));
            $this->CreatorUserID=htmlspecialchars(strip_tags($this->CreatorUserID));
        
            // bind data
            $stmt->bindParam(":SeriesName", $this->SeriesName);
			$stmt->bindParam(":Finished", $this->Finished);
            $stmt->bindParam(":CreatorUserID", $this->CreatorUserID);
			
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ single
        public function getSingleSeries(){
            $sqlQuery = "SELECT *
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       SeriesID = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->SeriesID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->SeriesID = $dataRow['SeriesID'];
            $this->SeriesName = $dataRow['SeriesName'];
			$this->Finished = $dataRow['Finished'];
            $this->CreatorUserID = $dataRow['CreatorUserID'];
        }        

        // UPDATE
        public function updateSeries(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        SeriesName = :SeriesName, 
						Finished = :Finished
                    WHERE 
                        SeriesID = :SeriesID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->SeriesID=htmlspecialchars(strip_tags($this->SeriesID));
            $this->SeriesName=htmlspecialchars(strip_tags($this->SeriesName));
			$this->Finished=htmlspecialchars(strip_tags($this->Finished));
        
            // bind data
            $stmt->bindParam(":SeriesID", $this->SeriesID);
            $stmt->bindParam(":SeriesName", $this->SeriesName);
			$stmt->bindParam(":Finished", $this->Finished);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }	

        // DELETE
        function deleteSeries(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE SeriesID = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->SeriesID=htmlspecialchars(strip_tags($this->SeriesID));
        
            $stmt->bindParam(1, $this->SeriesID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
?>