<?php
    class Edition{

        // Connection
        protected $conn;

        // Tables
        protected $db_table = "edition";
		protected $db_parent_table = "item";
		protected $db_child_table;
		protected $db_edition_user_table = "edition_user";
		protected $db_collection = "edition_collection";
		protected $db_series_table = "series";
		protected $db_genre_table = "genre";

        // Columns
		public $EditionID;
		public $ItemID;
		public $ItemType;
		public $CreatorUserID;
		public $ItemName;
		public $Year;
		public $EAN13;
		public $SeriesID;
		public $SeriesName;
		public $GenreID1;
		public $GenreID2;
		public $GenreID3;
		public $GenreName1;
		public $GenreName2;
		public $GenreName3;
		public $UserID;
		public $IsOwned;
		public $CollectionID;
		public $N_Usuarios;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET ITEMS
        public function getEditions(){
            if(isset($_GET['user'])) return $this->getEditionsOfUser();
            if(isset($_GET['collection'])) return $this->getEditionsOfCollections();
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, c.* 
				FROM ' . $this->db_table. ' e 
				INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
				INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
				LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
				WHERE i.ItemType = ' .$this->ItemType;
			if(isset($_GET['item'])){
				$item = $_GET['item'];
				$sqlQuery = $sqlQuery . ' AND i.ItemID = ' .$item;
			}
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		public function getEditionsOfUser(){
			if(!isset($_GET['user'])) return false;
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, c.*, u.IsOwned
				FROM ' . $this->db_table. ' e 
				INNER JOIN ' .$this->db_edition_user_table. ' u ON u.EditionID=e.EditionID
				INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
				INNER JOIN ' .$this->db_child_table. ' c ON e.EditionID = c.EditionID
				LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
				WHERE i.ItemType = ' .$this->ItemType. ' AND u.UserID = ' .$_GET['user']. ' ORDER BY i.ItemName, e.EditionID';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		public function getAllEditionsOfUser(){
			if(!isset($_GET['user'])) return false;
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, e.EditionID, u.IsOwned,
				c1.BookID, c1.ISBN, c1.NroPaginas, c1.Editorial, c1.Edicion, c1.Idioma, c1.Tipo, 
				c2.MusicID, c2.Formato, c2.NroPistas, c2.NroDiscos, c2.Sello, c2.NotasVersion,
				c3.VideoID, c3.FormatoVideo, c3.TipoVideo, c3.Sistema, c3.NroDiscosVideo, c3.RegionVideo, c3.Temporada, c3.VolumenVideo, c3.NroEpisodios,
				c4.GameID, c4.Plataforma, c4.FormatoJuego, c4.RegionJuego, c4.Distribuidora, c4.Estudio, c4.NotasEdJuego,
				c5.ComicID, c5.ISBNComic, c5.TipoComic, c5.FormatoComic, c5.NroComic, c5.EditorialComic, c5.Origen, c5.IdiomaComic
				FROM ' . $this->db_table. ' e 
				INNER JOIN ' .$this->db_edition_user_table. ' u ON u.EditionID=e.EditionID
				INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
				LEFT JOIN bookedition c1 ON e.EditionID = c1.EditionID
				LEFT JOIN musicedition c2 ON e.EditionID = c2.EditionID
				LEFT JOIN videoedition c3 ON e.EditionID = c3.EditionID
				LEFT JOIN gameedition c4 ON e.EditionID = c4.EditionID
				LEFT JOIN comicedition c5 ON e.EditionID = c5.EditionID
				LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
				WHERE u.UserID = ' .$_GET['user']. 
				' ORDER BY i.ItemName, e.EditionID';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        public function getEditionsOfCollections(){
			if(!isset($_GET['collection'])) return false;
            $sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, e.EditionID,
				c1.BookID, c1.ISBN, c1.NroPaginas, c1.Editorial, c1.Edicion, c1.Idioma, c1.Tipo, 
				c2.MusicID, c2.Formato, c2.NroPistas, c2.NroDiscos, c2.Sello, c2.NotasVersion,
				c3.VideoID, c3.FormatoVideo, c3.TipoVideo, c3.Sistema, c3.NroDiscosVideo, c3.RegionVideo, c3.Temporada, c3.VolumenVideo, c3.NroEpisodios,
				c4.GameID, c4.Plataforma, c4.FormatoJuego, c4.RegionJuego, c4.Distribuidora, c4.Estudio, c4.NotasEdJuego, 
				c5.ComicID, c5.ISBNComic, c5.TipoComic, c5.FormatoComic, c5.NroComic, c5.EditorialComic, c5.Origen, c5.IdiomaComic
                FROM ' .$this->db_collection. ' ec 
                INNER JOIN ' .$this->db_table. ' e ON e.EditionID=ec.EditionID
				INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID=i.ItemID
				LEFT JOIN bookedition c1 ON c1.EditionID=e.EditionID
				LEFT JOIN musicedition c2 ON c2.EditionID=e.EditionID
				LEFT JOIN videoedition c3 ON c3.EditionID=e.EditionID
				LEFT JOIN gameedition c4 ON c4.EditionID=e.EditionID
				LEFT JOIN comicedition c5 ON c5.EditionID=e.EditionID
				LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
				WHERE ec.CollectionID=' .$_GET['collection']. 
				' ORDER BY i.ItemName, e.EditionID';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        public function getWishlistOfUser(){
			if(!isset($_GET['user'])) return false;
			$sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, e.EditionID,
				c1.BookID, c1.ISBN, c1.NroPaginas, c1.Editorial, c1.Edicion, c1.Idioma, c1.Tipo, 
				c2.MusicID, c2.Formato, c2.NroPistas, c2.NroDiscos, c2.Sello, c2.NotasVersion, c3.VideoID, c3.FormatoVideo, c3.TipoVideo, c3.Sistema, c3.NroDiscosVideo, c3.RegionVideo, c3.Temporada, c3.VolumenVideo, c3.NroEpisodios,
				c4.GameID, c4.Plataforma, c4.FormatoJuego, c4.RegionJuego, c4.Distribuidora, c4.Estudio, c4.NotasEdJuego, 
				c5.ComicID, c5.ISBNComic, c5.TipoComic, c5.FormatoComic, c5.NroComic, c5.EditorialComic, c5.Origen, c5.IdiomaComic, u.IsOwned
				FROM ' . $this->db_table. ' e 
				INNER JOIN ' .$this->db_edition_user_table. ' u ON u.EditionID=e.EditionID AND u.IsOwned = 0
				INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
				LEFT JOIN bookedition c1 ON e.EditionID = c1.EditionID
				LEFT JOIN musicedition c2 ON e.EditionID = c2.EditionID
				LEFT JOIN videoedition c3 ON e.EditionID = c3.EditionID
				LEFT JOIN gameedition c4 ON c4.EditionID=e.EditionID
				LEFT JOIN comicedition c5 ON c5.EditionID=e.EditionID
				LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
				WHERE u.UserID = ' .$_GET['user']. 
				' ORDER BY i.ItemName, e.EditionID';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		public function getOwnedByUser() {
			if(!isset($_GET['user'])) return false;
			$sqlQuery = 'SELECT pi.UserID, e.ItemID, pi.EditionID, pi.IsOwned
				FROM '.$this->db_edition_user_table.' pi JOIN '.$this->db_table.' e ON pi.EditionID = e.EditionID 
				WHERE UserID='.$_GET['user'];
			if(isset($_GET['item']))
				$sqlQuery = $sqlQuery.' AND e.ItemID='.$_GET['item'];
			if(isset($_GET['edition']))
				$sqlQuery = $sqlQuery.' AND pi.EditionID='.$_GET['edition'];
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
		}
		
        // CREATE
		protected function createChildEdition() {}
		
        public function createEdition(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
						ItemID	= :ItemID,
						ItemType = :ItemType,
						Year = :Year,
						EAN13 = :EAN13,
						CreatorUserID = :CreatorUserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
			$this->ItemType=htmlspecialchars(strip_tags($this->ItemType));
			$this->Year=htmlspecialchars(strip_tags($this->Year));
			$this->EAN13=htmlspecialchars(strip_tags($this->EAN13));
            $this->CreatorUserID=htmlspecialchars(strip_tags($this->CreatorUserID));
        
            // bind data
            $stmt->bindParam(":ItemID", $this->ItemID);
			$stmt->bindParam(":ItemType", $this->ItemType);
			$stmt->bindParam(":Year", $this->Year);
			$stmt->bindParam(":EAN13", $this->EAN13);
            $stmt->bindParam(":CreatorUserID", $this->CreatorUserID);
        
            if($stmt->execute()){
				$this->EditionID = $this->conn->lastInsertId();
				return $this->createChildEdition();
            }
            return false;
        }

        // READ single
		public function getSingleEdition() {
			// a sobreescribir
		}
		
		// EDICIÓN A USUARIO
		public function addEditionToUser() {
			$sqlQuery = "INSERT INTO
                        ". $this->db_edition_user_table ."
                    SET
						UserID	= :UserID,
						EditionID = :EditionID,
						IsOwned = :IsOwned";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
			$this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
            $this->IsOwned=htmlspecialchars(strip_tags($this->IsOwned));
        
            // bind data
            $stmt->bindParam(":UserID", $this->UserID);
			$stmt->bindParam(":EditionID", $this->EditionID);
            $stmt->bindParam(":IsOwned", $this->IsOwned);
        
            if($stmt->execute()){
				return true;
            }
            return false;
		}
		
		public function updateEditionToUser(){
            $sqlQuery = "UPDATE ". $this->db_edition_user_table ." SET
                        IsOwned = :IsOwned
                    WHERE UserID = :UserID AND EditionID = :EditionID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->UserID=htmlspecialchars(strip_tags($this->UserID));
			$this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
            $this->IsOwned=htmlspecialchars(strip_tags($this->IsOwned));
        
            // bind data
            $stmt->bindParam(":UserID", $this->UserID);
			$stmt->bindParam(":EditionID", $this->EditionID);
            $stmt->bindParam(":IsOwned", $this->IsOwned);
        
            if($stmt->execute()){
				return true;
            }
            return false;
        }
		
		function removeEditionFromUser(){
            $sqlQuery = "DELETE FROM " . $this->db_edition_user_table . " WHERE UserID = ? AND EditionID = ?;
			DELETE FROM " .$this->db_collection. " WHERE EditionID=? AND CollectionID IN 
			(SELECT CollectionID FROM collection WHERE UserID=?)";
	
            $stmt = $this->conn->prepare($sqlQuery);
        
			$this->UserID=htmlspecialchars(strip_tags($this->UserID));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
        
            $stmt->bindParam(1, $this->UserID);
			$stmt->bindParam(2, $this->EditionID);
			$stmt->bindParam(3, $this->EditionID);
			$stmt->bindParam(4, $this->UserID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
		
		// ADD TO COLLECTION
		public function addEditionToCollection(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_collection ."
                    SET
                        CollectionID = :CollectionID, 
						ItemID = :ItemID, 
						ItemType = :ItemType, 
                        EditionID = :EditionID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->CollectionID=htmlspecialchars(strip_tags($this->CollectionID));
			$this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
			$this->ItemType=htmlspecialchars(strip_tags($this->ItemType));
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
        
            // bind data
            $stmt->bindParam(":CollectionID", $this->CollectionID);
			$stmt->bindParam(":ItemID", $this->ItemID);
			$stmt->bindParam(":ItemType", $this->ItemType);
            $stmt->bindParam(":EditionID", $this->EditionID);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }
		
		// REMOVE FROM COLLECTION
        function removeEditionFromCollection(){
            $sqlQuery = "DELETE FROM " . $this->db_collection . 
				" WHERE CollectionID = ? AND ItemID = ? AND EditionID = ?";
				
            $stmt = $this->conn->prepare($sqlQuery);
			
			$this->CollectionID=htmlspecialchars(strip_tags($this->CollectionID));
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
			$this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
        
            $stmt->bindParam(1, $this->CollectionID);
			$stmt->bindParam(2, $this->ItemID);
			$stmt->bindParam(3, $this->EditionID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

        // UPDATE
		protected function updateChildEdition() {}
		
        public function updateEdition(){
			
            return $this->updateChildEdition();
        }

        // DELETE
        function deleteEdition(){
			
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE EditionID = ?;
				DELETE FROM " .$this->db_child_table. " WHERE EditionID = ?;
				DELETE FROM " .$this->db_edition_user_table. " WHERE EditionID = ?;
				DELETE FROM " .$this->db_collection. " WHERE EditionID = ?;
				DELETE FROM website WHERE EntityID = ? && EntityType = 'edition';";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
        
            $stmt->bindParam(1, $this->EditionID);
			$stmt->bindParam(2, $this->EditionID);
			$stmt->bindParam(3, $this->EditionID);
			$stmt->bindParam(4, $this->EditionID);
			$stmt->bindParam(5, $this->EditionID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
		
		function usedByOthers() {
			$sqlQuery = "SELECT DISTINCT(UserID) FROM `edition_user` WHERE EditionID=? AND UserID <> 
			(SELECT CreatorUserID AS UserID FROM edition WHERE EditionID=?)";
			$stmt = $this->conn->prepare($sqlQuery);
        
            $this->EditionID=htmlspecialchars(strip_tags($this->EditionID));
        
            $stmt->bindParam(1, $this->EditionID);
			$stmt->bindParam(2, $this->EditionID);
        
            $stmt->execute();
            return $stmt;
			
		}

		public function search($params) {
            $sqlQuery = 'SELECT i.ItemID, i.ItemName, i.ItemType, e.Year, e.EAN13, i.SeriesID, s.SeriesName, e.CreatorUserID, e.EditionID, 
			c1.BookID, c1.ISBN, c1.NroPaginas, c1.Editorial, c1.Edicion, c1.Idioma, c1.Tipo, 
			c2.MusicID, c2.Formato, c2.NroPistas, c2.NroDiscos, c2.Sello, c2.NotasVersion,
			c3.VideoID, c3.FormatoVideo, c3.TipoVideo, c3.Sistema, c3.NroDiscosVideo, c3.RegionVideo, c3.Temporada, c3.VolumenVideo, c3.NroEpisodios,
			c4.GameID, c4.Plataforma, c4.FormatoJuego, c4.RegionJuego, c4.Distribuidora, c4.Estudio, c4.NotasEdJuego,
			c5.ComicID, c5.ISBNComic, c5.TipoComic, c5.FormatoComic, c5.NroComic, c5.EditorialComic, c5.Origen, c5.IdiomaComic
			FROM ' . $this->db_table. ' e 
			INNER JOIN ' .$this->db_parent_table. ' i ON e.ItemID = i.ItemID
			LEFT JOIN bookedition c1 ON e.EditionID = c1.EditionID
			LEFT JOIN musicedition c2 ON e.EditionID = c2.EditionID
			LEFT JOIN videoedition c3 ON e.EditionID = c3.EditionID
			LEFT JOIN gameedition c4 ON e.EditionID = c4.EditionID
			LEFT JOIN comicedition c5 ON e.EditionID = c5.EditionID
			LEFT JOIN ' .$this->db_series_table. ' s ON i.SeriesID = s.SeriesID
			WHERE ';
			$i = 0;
			foreach($params as $p) {
				$i++;
				if($p->valor!==null) {
					if($i>1) {
						$sqlQuery = $sqlQuery.' AND ';
					}
					if ($p->campo === "ItemType") {
						$sqlQuery = $sqlQuery ."i.".$p->campo. " LIKE '%" .$p->valor."%'";
					} else {
						$sqlQuery = $sqlQuery .$p->campo. " LIKE '%" .$p->valor."%'";
					}
				}
			}
			$sqlQuery = $sqlQuery.' ORDER BY i.ItemName, e.EditionID';
			//echo($sqlQuery);
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
		}

    }
?>