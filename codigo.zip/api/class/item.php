<?php
    include 'person.php';
    class Item{

        // Connection
        private $conn;

        // Table
        private $db_table = "item";
        private $db_person_table = "person";
        private $db_person_item_table = "person_item";
		private $db_series = "series";
		private $db_genre = "genre";

        // Columns
        public $ItemID;
		public $ItemName;
		public $ItemType;
		public $ItemTypeName;
		public $SeriesID;
		public $GenreID1;
		public $GenreID2;
		public $GenreID3;
		public $GenreName1;
		public $GenreName2;
		public $GenreName3;
		public $CreatorUserID;
		public $CollectionID;
        public $EditionID;
        public $People;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

		// GET ITEMS
        public function getItems(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['name'])){
				$name = $_GET['name'];
				$sqlQuery = $sqlQuery . ' WHERE ItemName LIKE "%' .$name. '%"';
			} else if (isset($_GET['type'])){
				$type = $_GET['type'];
				$sqlQuery = $sqlQuery . ' WHERE ItemType = '.$type;
			}
			$sqlQuery = $sqlQuery . ' ORDER BY ItemName';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		public function getItemsByPerson() {
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['person'])){
				$person = $_GET['person'];
				$sqlQuery = $sqlQuery . ' WHERE ItemID IN (
				SELECT DISTINCT ItemID FROM ' .$this->db_person_item_table .' WHERE PersonID = ' .$person. ' )';
			}
			$sqlQuery = $sqlQuery . ' ORDER BY ItemName';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
		}

        // CREATE
        public function createItem(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        ItemName = :ItemName, 
						ItemType = :ItemType, 
						SeriesID = :SeriesID, 
						GenreID1 = :GenreID1,
						GenreID2 = :GenreID2,
						GenreID3 = :GenreID3,
                        CreatorUserID = :CreatorUserID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->ItemName=htmlspecialchars(strip_tags($this->ItemName));
			$this->ItemType=htmlspecialchars(strip_tags($this->ItemType));
			$this->SeriesID=htmlspecialchars(strip_tags($this->SeriesID));
			$this->GenreID1=htmlspecialchars(strip_tags($this->GenreID1));
			$this->GenreID2=htmlspecialchars(strip_tags($this->GenreID2));
			$this->GenreID3=htmlspecialchars(strip_tags($this->GenreID3));
            $this->CreatorUserID=htmlspecialchars(strip_tags($this->CreatorUserID));
        
            // bind data
            $stmt->bindParam(":ItemName", $this->ItemName);
			$stmt->bindParam(":ItemType", $this->ItemType);
			$stmt->bindParam(":SeriesID", $this->SeriesID);
			$stmt->bindParam(":GenreID1", $this->GenreID1);
			$stmt->bindParam(":GenreID2", $this->GenreID2);
			$stmt->bindParam(":GenreID3", $this->GenreID3);
            $stmt->bindParam(":CreatorUserID", $this->CreatorUserID);
        
            if($stmt->execute()){
               return $this->conn->lastInsertId();
            }
            return false;
        }

        // READ single
        public function getSingleItem(){
            $sqlQuery = "SELECT i.*, s.SeriesName, g1.GenreName GenreName1, g2.GenreName GenreName2, g3.GenreName GenreName3
			FROM ". $this->db_table ." i
			LEFT JOIN ".$this->db_series." s ON i.SeriesID=s.SeriesID
			LEFT JOIN ".$this->db_genre." g1 ON i.GenreID1=g1.GenreID
			LEFT JOIN ".$this->db_genre." g2 ON i.GenreID2=g2.GenreID
			LEFT JOIN ".$this->db_genre." g3 ON i.GenreID3=g3.GenreID
            WHERE ItemID = ? LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->ItemID);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->ItemID = $dataRow['ItemID'];
            $this->ItemName = $dataRow['ItemName'];
			$this->ItemType = $dataRow['ItemType'];
            $this->SeriesID = $dataRow['SeriesID'];
			$this->SeriesName = $dataRow['SeriesName'];
			$this->GenreID1 = $dataRow['GenreID1'];
			$this->GenreName1 = $dataRow['GenreName1'];
			$this->GenreID2 = $dataRow['GenreID2'];
			$this->GenreName2 = $dataRow['GenreName2'];
			$this->GenreID3 = $dataRow['GenreID3'];
			$this->GenreName3 = $dataRow['GenreName3'];
            $this->People = $this->getPeople($this->ItemID);
            $this->CreatorUserID = $dataRow['CreatorUserID'];
        }

        function getPeople($itemID) {
            $sqlQuery = 'SELECT p.PersonID, p.Names, p.LastNames, i.Role 
            FROM ' . $this->db_person_item_table.
            ' i INNER JOIN ' .$this->db_person_table. ' p ON p.PersonID=i.PersonID
            WHERE ItemID = ' .$itemID. '';
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();

            $itemCount = $stmt->rowCount();
            if($itemCount > 0){
                $personArr = array();
                $personArr["body"] = array();
                $personArr["itemCount"] = $itemCount;
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                    extract($row);
                    $e = array(
                        "PersonID" => $PersonID,
                        "Names" => $Names,
                        "LastNames" => $LastNames,
                        "Role" => $Role
                    );
                    array_push($personArr["body"], $e);
                }
                /*return json_encode($personArr)*/
                return $personArr["body"];
            }
            return null;
        }
		
		function getPeopleList($itemID) {
			$sqlQuery = 'SELECT p.PersonID, p.Names, p.LastNames, i.Role 
            FROM ' . $this->db_person_item_table.
            ' i INNER JOIN ' .$this->db_person_table. ' p ON p.PersonID=i.PersonID
            WHERE ItemID = ' .$itemID. " AND Role NOT LIKE '%secundario%'";
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();

            $itemCount = $stmt->rowCount();
            if($itemCount > 0){
				$peopleList = ""; $i=$itemCount;
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					$peopleList = $peopleList.$row['Names'];
					if($row['LastNames']) {$peopleList = $peopleList.' ';}
					$peopleList = $peopleList.$row['LastNames']." (".$row['Role'].")";
					$i--;
                    if ($i > 0) $peopleList = $peopleList.", ";
                }
                return $peopleList;
            }
            return "Sin gente";
		}
		
		function getPeopleListNoRole($itemID) {
			$sqlQuery = 'SELECT p.PersonID, p.Names, p.LastNames
            FROM ' . $this->db_person_item_table.
            ' i INNER JOIN ' .$this->db_person_table. ' p ON p.PersonID=i.PersonID
            WHERE ItemID = ' .$itemID. " AND Role NOT LIKE '%secundario%' GROUP BY p.PersonID";
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();

            $itemCount = $stmt->rowCount();
            if($itemCount > 0){
				$peopleList = ""; $i=$itemCount;
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					$peopleList = $peopleList.$row['Names'];
					if($row['LastNames']) $peopleList = $peopleList.' '.$row['LastNames'];
					$i--;
                    if ($i > 0) $peopleList = $peopleList.", ";
                }
                return $peopleList;
            }
            return null;
		}

        // GET SERIES
        public function getItemsOfSeries(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['series'])){
				$series = $_GET['series'];
				$sqlQuery = $sqlQuery . ' WHERE SeriesID = ' .$series;
			}
			$sqlQuery = $sqlQuery . ' ORDER BY ItemName';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
		//GET GENRE
		public function getItemsOfGenre(){
			$sqlQuery = 'SELECT * FROM ' . $this->db_table;
			if(isset($_GET['genre'])){
				$genre = $_GET['genre'];
				$sqlQuery = $sqlQuery . ' WHERE GenreID1 = ' .$genre. ' OR GenreID2 = ' .$genre. ' OR GenreID3 = ' .$genre;
			}
			$sqlQuery = $sqlQuery . ' ORDER BY ItemName';
			if(isset($_GET['page']) && isset($_GET['num'])) {
				$offset = ($_GET['page'] - 1) * $_GET['num'];
				$sqlQuery = $sqlQuery . ' LIMIT ' .$_GET['num']. ' OFFSET ' .$offset;
			}
			$stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
		
        // UPDATE
        public function updateItem(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        ItemName = :ItemName, 
						SeriesID =:SeriesID,
						GenreID1 = :GenreID1,
						GenreID2 = :GenreID2,
						GenreID3 = :GenreID3
                    WHERE 
                        ItemID = :ItemID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
            $this->ItemName=htmlspecialchars(strip_tags($this->ItemName));
            $this->SeriesID=htmlspecialchars(strip_tags($this->SeriesID));
			$this->GenreID1=htmlspecialchars(strip_tags($this->GenreID1));
			$this->GenreID2=htmlspecialchars(strip_tags($this->GenreID2));
			$this->GenreID3=htmlspecialchars(strip_tags($this->GenreID3));
        
            // bind data
            $stmt->bindParam(":ItemID", $this->ItemID);
            $stmt->bindParam(":ItemName", $this->ItemName);
            $stmt->bindParam(":SeriesID", $this->SeriesID);
			$stmt->bindParam(":GenreID1", $this->GenreID1);
			$stmt->bindParam(":GenreID2", $this->GenreID2);
			$stmt->bindParam(":GenreID3", $this->GenreID3);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }	

        // DELETE
        function deleteItem(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE ItemID = ?;
			DELETE FROM " .$this->db_person_item_table . " WHERE ItemID = ?;
			DELETE FROM " .$this->ItemTypeName. "edition WHERE ItemID = ?;
			DELETE FROM edition_collection WHERE ItemID = ?;
			DELETE FROM edition_user WHERE EditionID IN (SELECT EditionID FROM edition WHERE ItemID = ?);
			DELETE FROM edition WHERE ItemID = ?;
			DELETE FROM website WHERE EntityID = ? && EntityType = 'item';";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
        
            $stmt->bindParam(1, $this->ItemID);
			$stmt->bindParam(2, $this->ItemID);
			$stmt->bindParam(3, $this->ItemID);
			$stmt->bindParam(4, $this->ItemID);
			$stmt->bindParam(5, $this->ItemID);
			$stmt->bindParam(6, $this->ItemID);
			$stmt->bindParam(7, $this->ItemID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
		
		function usedByOthers() {
			$sqlQuery = "SELECT e.*, eu.UserID AS UsingUserID, i.CreatorUserID AS ItemUserID FROM edition e 
			LEFT JOIN edition_user eu ON e.EditionID=eu.EditionID
			INNER JOIN item i ON e.ItemID=i.ItemID AND e.ItemID=?
			WHERE e.CreatorUserID<>i.CreatorUserID || eu.UserID<>i.CreatorUserID";
			$stmt = $this->conn->prepare($sqlQuery);
        
            $this->ItemID=htmlspecialchars(strip_tags($this->ItemID));
        
            $stmt->bindParam(1, $this->ItemID);
        
            $stmt->execute();
            return $stmt;
			
		}

    }
?>