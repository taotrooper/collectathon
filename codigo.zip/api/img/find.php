<?php

header('Access-Control-Allow-Origin: *');
$target_path = "../../collectathon/uploads/";
$file = null;
$found = null;
if ($_GET['name']) {
	/*$files = scandir($target_path);
	foreach ($files as $file) {
		if ($file !== "." && $file !== ".." && strpos($_GET['name'], $file) !== false) {
			$found = $file;
		}
	}*/
	$found = file_exists($target_path.$_GET['name']);
	if($found) {
		$file = $_GET['name'];
	}
}
 
header('Content-type: application/json');
$data = [
/*	'found' => $found !== null,
	'filename' => $found*/
	'found' => $found,
	'filename' => $file
];
echo json_encode($data);

?>