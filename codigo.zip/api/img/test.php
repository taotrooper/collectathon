<?php

$folder = "../../collectathon/uploads/";
$name = "26.jpg";
$target_path = $folder.$name;
make_thumb($target_path, $folder."thumb/".$name, 0.1);

function make_thumb($src, $dest, $ratio) {

    /* read the source image */
    $source_image = imagecreatefromjpeg($src);
    $width = imagesx($source_image);
    $height = imagesy($source_image);

    /* find the "desired height" of this thumbnail, relative to the desired width  */
	$desired_width = floor($width * $ratio);
    $desired_height = floor($height * $ratio);

    /* create a new, "virtual" image */
    $virtual_image = imagecreatetruecolor($desired_width, $desired_height);

    /* copy source image at a resized size */
    imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);

    /* create the physical thumbnail image to its destination */
    imagejpeg($virtual_image, $dest);
}

?>