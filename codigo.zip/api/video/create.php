<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/video.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Video($db);

    $data = json_decode(file_get_contents("php://input"));

    $item->ItemID = $data->ItemID;
	$item->Year = $data->Year;
	$item->EAN13 = $data->EAN13;
	$item->FormatoVideo = $data->FormatoVideo;
	$item->TipoVideo = $data->TipoVideo;
	$item->Sistema = $data->Sistema;
	$item->NroDiscosVideo = $data->NroDiscosVideo;
	$item->RegionVideo = $data->RegionVideo;
	$item->Temporada = $data->Temporada;
	$item->VolumenVideo = $data->VolumenVideo;
	$item->NroEpisodios = $data->NroEpisodios;
	$item->CreatorUserID = $data->CreatorUserID;
    
	$result = $item->createEdition();
	
    if($result){
		http_response_code(200);
        echo json_encode(
            array("EditionID" => $result)
        );
    } else{
        echo json_encode(
            array("Message" => "No pudo ser creado el vídeo.")
        );
    }
?>