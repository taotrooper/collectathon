<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/game.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Game($db);
	$itemclass = new Item($db);
	
	/*$user = isset($_GET['user']) ? $_GET['user'] : die();*/
	
	$stmt = $items->getEditions();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
			$Summary = $itemclass->getPeopleList($ItemID);
			if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
			if($Plataforma != NULL) $Summary = $Summary.', '.$Plataforma;
 			if($FormatoJuego != NULL) $Summary = $Summary.', '.$FormatoJuego;
			if($RegionJuego != NULL) $Summary = $Summary.', '.$RegionJuego;
			if($Distribuidora != NULL) $Summary = $Summary.', '.$Distribuidora;
			if($Estudio != NULL) $Summary = $Summary.', '.$Estudio;
			if($NotasEdJuego != NULL) $Summary = $Summary.', '.$NotasEdJuego;
			$e = array(
                "ItemID" =>  $ItemID,
				"ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"EditionID" => $EditionID,
				"Summary" => $Summary,
				"IsOwned" => $IsOwned
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>