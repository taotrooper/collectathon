<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/game.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Game($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
	$item->EditionID = $data->EditionID;
	$item->Year = $data->Year;
	$item->EAN13 = $data->EAN13;
	$item->Plataforma = $data->Plataforma;
	$item->FormatoJuego = $data->FormatoJuego;
	$item->RegionJuego = $data->RegionJuego;
	$item->Distribuidora = $data->Distribuidora;
	$item->Estudio = $data->Estudio;
	$item->NotasEdJuego = $data->NotasEdJuego;
    
    if($item->updateEdition()){
		http_response_code(200);
		$emp_arr = array(
            "Message" =>  "Juego actualizado."
        );
		echo json_encode($emp_arr);
    } else{
		$emp_arr = array(
            "Message" =>  "No pudo actualizarse el juego."
        );
		echo json_encode($emp_arr);
    }
?>