<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/game.php';
    
    $database = new Database();
    $db = $database->getConnection();
    
    $item = new Game($db);
    
    $data = json_decode(file_get_contents("php://input"));
    
    $item->EditionID = $data->EditionID;
	$stmt = $item->usedByOthers();
    $itemCount = $stmt->rowCount();
	
	if($itemCount > 0) {
		echo json_encode(
			array(
				"message" => "No se puede borrar la edición, la están usando otros usuarios.",
				"otros" => $itemCount
			)
		);
	} else {
		if($item->deleteEdition()){
			echo json_encode(
				array(
					"Message" => "Juego eliminado.",
					"otros" => $itemCount
				)
			);
		} else{
			echo json_encode(
				array(
					"Message" => "No pudo eliminarse la edición.",
					"otros" => $itemCount
				)
			);
		}
	}
    
?>