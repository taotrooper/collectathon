<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/person.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Person($db);

	$stmt = $items->getPeople();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $personArr = array();
        $personArr["body"] = array();
        $personArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "PersonID" => $PersonID,
                "Names" => $Names,
                "LastNames" => $LastNames,
				"CreatorUserID" => $CreatorUserID
            );

            array_push($personArr["body"], $e);
        }
        echo json_encode($personArr);
    }

    else{
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>