<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/genre.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Genre($db);
	
	$stmt = $items->getGenres();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "GenreID" => $GenreID,
                "GenreName" => $GenreName,
				"GenreType" => $GenreType
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>