<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/edition.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Edition($db);
	$itemclass = new Item($db);
	
	$stmt = $items->getEditions();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
			$Summary = $itemclass->getPeopleList($ItemID);
			switch($ItemType) {
				case 1: 
					if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
					if($Editorial != NULL) $Summary = $Summary.', '.$Editorial;
					if($Edicion != NULL && $Edicion > 0) $Summary = $Summary.', '.$Edicion.'ª Ed';
					if($Tipo != NULL) $Summary = $Summary.', '.$Tipo;
					if($ISBN != NULL) $Summary = $Summary.', '.$ISBN;
				break;
				case 2:
					if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
					if($Formato != NULL) $Summary = $Summary.', '.$Formato;
					if($Sello != NULL) $Summary = $Summary.', '.$Sello;
					if($NotasVersion != NULL) $Summary = $Summary.', '.$NotasVersion;
				break;
				case 3:
					if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
					if($FormatoVideo != NULL) $Summary = $Summary.', '.$FormatoVideo;
					if($TipoVideo != NULL) $Summary = $Summary.', '.$TipoVideo;
					if($Sistema != NULL) $Summary = $Summary.', '.$Sistema;
					if($RegionVideo != NULL) $Summary = $Summary.', '.$RegionVideo;
					if($Temporada != NULL && $Temporada>0) $Summary = $Summary.', Temp. '.$Temporada;
					if($VolumenVideo != NULL && $VolumenVideo>0) $Summary = $Summary.', Vol. '.$VolumenVideo;
				break;
				case 4:
					if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
					if($Plataforma != NULL) $Summary = $Summary.', '.$Plataforma;
					if($FormatoJuego != NULL) $Summary = $Summary.', '.$FormatoJuego;
					if($RegionJuego != NULL) $Summary = $Summary.', '.$RegionJuego;
					if($Distribuidora != NULL) $Summary = $Summary.', '.$Distribuidora;
					if($Estudio != NULL) $Summary = $Summary.', '.$Estudio;
					if($NotasEdJuego != NULL) $Summary = $Summary.', '.$NotasEdJuego;
				break;
				case 5:
					if($Year != NULL && $Year != 0) $Summary = $Summary.', '.$Year;
					if($NroComic != NULL && $NroComic > 0) $Summary = $Summary.', Nº '.$NroComic;
					if($Origen != NULL) $Summary = $Summary.', '.$Origen;
					if($FormatoComic != NULL) $Summary = $Summary.', '.$FormatoComic;
					if($TipoComic != NULL) $Summary = $Summary.', '.$TipoComic;
					if($EditorialComic != NULL) $Summary = $Summary.', '.$EditorialComic;
					if($ISBNComic != NULL) $Summary = $Summary.', '.$ISBNComic;
				break;
			}
			$e = array(
                "ItemID" =>  $ItemID,
				"ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"EditionID" => $EditionID,
				"Summary" => $Summary
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>