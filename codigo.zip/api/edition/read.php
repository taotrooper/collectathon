<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/edition.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Edition($db);
	$itemclass = new Item($db);
	
	$stmt = $items->getAllEditionsOfUser();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "ItemID" =>  $ItemID,
				"ItemName" => $ItemName,
				"ItemType" => $ItemType,
				"Year" => $Year,
				"EAN13" => $EAN13,
				"SeriesID" => $SeriesID,
				"SeriesName" => $SeriesName,
				"People" => $itemclass->getPeople($ItemID),
				"EditionID" => $EditionID,
				"CreatorUserID" => $CreatorUserID
            );
			
			switch($ItemType) {
				case 1: 
					$e['BookID'] = $BookID;
					$e['ISBN'] = $ISBN;
					$e['NroPaginas'] = $NroPaginas;
					$e['Editorial'] = $Editorial;
					$e['Edicion'] = $Edicion;
					$e['Idioma'] = $Idioma;
					$e['Tipo'] = $Tipo;
				break;
				case 2: 
					$e['MusicID'] = $MusicID;
					$e['Formato'] = $Formato;
					$e['NroPaginas'] = $NroPaginas;
					$e['NroPistas'] = $NroPistas;
					$e['Sello'] = $Sello;
					$e['NotasVersion'] = $NotasVersion;
				break;
				case 3:
					$e['VideoID'] = $VideoID;
					$e['FormatoVideo'] = $FormatoVideo;
					$e['TipoVideo'] = $TipoVideo;
					$e['Sistema'] = $Sistema;
					$e['NroDiscosVideo'] = $NroDiscosVideo;
					$e['RegionVideo'] = $RegionVideo;
					$e['Temporada'] = $Temporada;
					$e['VolumenVideo'] = $VolumenVideo;
					$e['NroEpisodios'] = $NroEpisodios;
				break;
				case 4:
					$e['GameID'] = $GameID;
					$e['Plataforma'] = $Plataforma;
					$e['FormatoJuego'] = $FormatoJuego;
					$e['RegionJuego'] = $RegionJuego;
					$e['Distribuidora'] = $Distribuidora;
					$e['Estudio'] = $Estudio;
					$e['NotasEdJuego'] = $NotasEdJuego;
				break;
				case 5:
					$e['ComicID'] = $ComicID;
					$e['ISBNComic'] = $ISBNComic;
					$e['TipoComic'] = $TipoComic;
					$e['FormatoComic'] = $FormatoComic;
					$e['NroComic'] = $NroComic;
					$e['EditorialComic'] = $EditorialComic;
					$e['Origen'] = $Origen;
					$e['IdiomaComic'] = $IdiomaComic;
				break;
			}

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>