<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/edition.php';
	include_once '../class/item.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Edition($db);
	$itemclass = new Item($db);
	
	$stmt = $items->getOwnedByUser();
    $itemCount = $stmt->rowCount();

    if($itemCount > 0){
        
        $itemArr = array();
        $itemArr["body"] = array();
        $itemArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "UserID" =>  $UserID,
				"ItemID" => $ItemID,
				"EditionID" => $EditionID,
				"IsOwned" => $IsOwned
            );

            array_push($itemArr["body"], $e);
        }
        echo json_encode($itemArr);
    }

    else{
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>